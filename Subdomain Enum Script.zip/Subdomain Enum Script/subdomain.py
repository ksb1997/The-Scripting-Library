import requests,json

i = open("domains.txt","r")

for domain in i:
    domain= domain.replace("\n","")
    url = "https://api.securitytrails.com/v1/domain/" + domain + "/subdomains"
    headers = {
        'accept': "application/json",
        'apikey': "68MWXM0yQuo7P8wf74dj4BjSUbXxFbrO"
        }
    response = requests.request("GET", url, headers=headers)
    rep = json.loads(response.text)
    print(domain + "'s" + " subdomain Count: ", len(rep['subdomains']))
    with open(domain+".txt","w") as file:
        for sub in rep['subdomains']:
            file.write(sub+"." + domain + "\n")